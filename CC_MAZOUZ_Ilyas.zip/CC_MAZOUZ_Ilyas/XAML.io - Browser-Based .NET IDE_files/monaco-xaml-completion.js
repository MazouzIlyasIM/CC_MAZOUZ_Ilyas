﻿// XAML Auto-Completion Provider for Monaco Editor
// Provides context-aware completion for XAML elements, properties, events, and enum values

(function() {
    'use strict';
    
    // Configuration constants
    const MAX_LOOKBACK_LINES = 50; // Maximum lines to search backwards for tag context
    
    window.XamlCompletionProvider = {
        completionData: null,
        completionProvider: null,
        typingListener: null,
        isAutoClosing: false,
        setupRetryCount: 0,
        
        // Initialize XAML completion with data
        initialize: function(completionDataJson) {
            try {
                this.completionData = JSON.parse(completionDataJson);
                
                if (!this.completionProvider && this.completionData) {
                    // Register completion provider with common XAML trigger characters
                    // Monaco automatically triggers on word boundaries, so we don't need all letters
                    this.completionProvider = monaco.languages.registerCompletionItemProvider('xml', {
                        triggerCharacters: ['<', ' ', '=', '.', '"', '/'],
                        provideCompletionItems: (model, position) => {
                            return this.provideCompletions(model, position);
                        }
                    });
                    
                    // Set up auto-closing tag handler
                    this.setupAutoClosingTags();
                    
                    console.log('[XAML Completion] Ready with', Object.keys(this.completionData.elements || {}).length, 'types');
                }
            } catch (err) {
                console.error('[XAML Completion] Error initializing:', err);
            }
        },
        
        // Set up auto-closing tag functionality
        setupAutoClosingTags: function() {
            const editor = document.getElementById('monacoContainer')?.editor;
            if (!editor) {
                // Editor not ready yet, retry after a short delay (max 10 retries = 5 seconds)
                if (this.setupRetryCount < 10) {
                    this.setupRetryCount++;
                    setTimeout(() => this.setupAutoClosingTags(), 500);
                } else {
                    console.warn('[XAML Auto-Close] Editor not found after 5 seconds, giving up');
                }
                return;
            }
            
            if (this.typingListener) return; // Already set up
            
            this.typingListener = editor.onDidChangeModelContent((e) => {
                if (!e.changes || e.changes.length === 0) return;
                
                // Ignore changes made by our own auto-closing logic
                if (this.isAutoClosing) return;
                
                const change = e.changes[0];
                // Check if user typed '>' to close an opening tag, or if a completion inserted text ending with '>'
                if (change.text === '>' || (change.text && change.text.endsWith('>'))) {
                    this.handleTagClosing(editor, change);
                }
            });
        },
        
        // Handle auto-insertion of closing tag
        handleTagClosing: function(editor, change) {
            const model = editor.getModel();
            
            // Calculate position after the inserted text
            // When text is inserted/replaced, we need the start position + length of new text
            // change.range gives us where the text was inserted
            const insertedTextLength = change.text ? change.text.length : 0;
            const position = {
                lineNumber: change.range.endLineNumber,
                column: change.range.startColumn + insertedTextLength
            };
            
            // Get text before and including the '>'
            const textBeforeCursor = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column
            });
            
            // Check if this is an opening tag (not self-closing, not closing tag)
            // Match pattern: < + tagName + optional attributes + >
            const tagMatch = textBeforeCursor.match(/<([a-zA-Z0-9_.]+)(?:\s+[^<>]*)?>$/);
            if (!tagMatch) return;
            
            const tagName = tagMatch[1];
            
            // Skip if this is a self-closing tag (ends with />)
            if (textBeforeCursor.trimEnd().endsWith('/>')) return;
            
            // Skip if this is a closing tag
            if (textBeforeCursor.includes('</' + tagName)) {
                const lastOpenTag = textBeforeCursor.lastIndexOf('<' + tagName);
                const lastCloseTag = textBeforeCursor.lastIndexOf('</' + tagName);
                if (lastCloseTag > lastOpenTag) return;
            }
            
            // Check if this is a property element (e.g., <Grid.Background>)
            // Property elements get inline closing tags, regular elements may get newlines
            const isPropertyElement = tagName.includes('.');
            
            // Check if this is a self-closing element or if a closing tag already exists nearby
            const textAfterCursor = model.getValueInRange({
                startLineNumber: position.lineNumber,
                startColumn: position.column,
                endLineNumber: position.lineNumber,
                endColumn: model.getLineMaxColumn(position.lineNumber)
            });
            
            // Don't auto-close if there's already content that suggests it's self-closing or already closed
            if (textAfterCursor.trimStart().startsWith('</')) return;
            
            // For property elements, insert closing tag inline (no newlines)
            if (isPropertyElement) {
                this.isAutoClosing = true;
                editor.executeEdits('auto-close-tag', [{
                    range: {
                        startLineNumber: position.lineNumber,
                        startColumn: position.column,
                        endLineNumber: position.lineNumber,
                        endColumn: position.column
                    },
                    text: `</${tagName}>`
                }]);
                
                // Move cursor between tags
                editor.setPosition(position);
                this.isAutoClosing = false;
                return;
            }
            
            // For regular elements, check if it's a known type that typically has content
            const typeInfo = this.completionData?.elements?.[tagName];
            const shouldAddNewlines = typeInfo && (typeInfo.contentType || typeInfo.contentProperty);
            
            this.isAutoClosing = true;
            
            if (shouldAddNewlines) {
                // Insert closing tag with newlines for better formatting
                const lineContent = model.getLineContent(position.lineNumber);
                const indent = lineContent.match(/^(\s*)/)[1];
                
                editor.executeEdits('auto-close-tag', [{
                    range: {
                        startLineNumber: position.lineNumber,
                        startColumn: position.column,
                        endLineNumber: position.lineNumber,
                        endColumn: position.column
                    },
                    text: `\n${indent}    \n${indent}</${tagName}>`
                }]);
                
                // Move cursor to indented position between tags
                editor.setPosition({
                    lineNumber: position.lineNumber + 1,
                    column: indent.length + 5
                });
            } else {
                // Simple closing tag for elements without typical content
                editor.executeEdits('auto-close-tag', [{
                    range: {
                        startLineNumber: position.lineNumber,
                        startColumn: position.column,
                        endLineNumber: position.lineNumber,
                        endColumn: position.column
                    },
                    text: `</${tagName}>`
                }]);
                
                // Move cursor between tags
                editor.setPosition(position);
            }
            
            this.isAutoClosing = false;
        },
        
        // Main completion provider
        provideCompletions: function(model, position) {
            try {
                if (!this.completionData || !this.completionData.elements) {
                    return { suggestions: [], incomplete: false };
                }
                
                const line = model.getLineContent(position.lineNumber);
                const textUntilPosition = line.substring(0, position.column - 1);
                const word = model.getWordUntilPosition(position);
                const range = {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: word.startColumn,
                    endColumn: word.endColumn
                };
                
                // Detect context
                const context = this.detectContext(model, position, textUntilPosition);
                
                if (context.isClosingTag) {
                    return this.getClosingTagCompletions(model, position, range);
                } else if (context.isAfterEquals) {
                    return this.getEnumCompletions(textUntilPosition, range);
                } else if (context.isAfterDot) {
                    return this.getDotCompletions(textUntilPosition, range, model, position);
                } else if (context.isInAttribute) {
                    return this.getAttributeCompletions(model, position, range);
                } else if (context.isAfterOpenTag) {
                    return this.getElementCompletions(model, position, textUntilPosition, range);
                }
                
                return { suggestions: [], incomplete: false };
            } catch (err) {
                console.error('[XAML Completion] Error in provideCompletions:', err);
                return { suggestions: [], incomplete: false };
            }
        },
        
        getClosingTagCompletions: function(model, position, range) {
            // Get all currently open tags with their positions
            const openTagsInfo = this.getOpenTagsWithPositions(model, position);
            
            if (openTagsInfo.length === 0) {
                return { suggestions: [], incomplete: false };
            }
            
            // Get the line content to analyze what needs to be replaced
            const line = model.getLineContent(position.lineNumber);
            const textBefore = line.substring(0, position.column - 1);
            
            // Check if the user typed '</' - we need to build a proper replacement range
            const closingTagMatch = textBefore.match(/<\/([a-zA-Z0-9_.]*)$/);
            if (!closingTagMatch) {
                return { suggestions: [], incomplete: false };
            }
            
            // Build replacement range that includes:
            // 1. Everything from start of line (to fix indentation)
            // 2. The '</' part and any partial tag name already typed
            // 3. Any trailing '>' that Monaco auto-inserted when user typed '<'
            //    (When user types '<', Monaco inserts '>', so typing '/' gives us '</>')
            const adjustedRange = {
                startLineNumber: position.lineNumber,
                endLineNumber: position.lineNumber,
                startColumn: 1,  // Start from beginning of line to replace indentation
                endColumn: this.findEndColumnForClosingTag(line, position.column)
            };
            
            // Suggest closing the most recent open tag first, then others
            const suggestions = [];
            
            for (let i = openTagsInfo.length - 1; i >= 0; i--) {
                const tagInfo = openTagsInfo[i];
                const tagName = tagInfo.name;
                const openingTagIndent = tagInfo.indent;
                
                suggestions.push({
                    label: `</${tagName}>`,
                    kind: monaco.languages.CompletionItemKind.Keyword,
                    insertText: `${openingTagIndent}</${tagName}>`,
                    detail: i === openTagsInfo.length - 1 ? 'Close current tag' : 'Close parent tag',
                    sortText: String.fromCharCode(65 + (openTagsInfo.length - 1 - i)), // A, B, C... for priority
                    range: adjustedRange
                });
            }
            
            return { suggestions, incomplete: false };
        },
        
        // Helper: Find the end column, including any auto-inserted '>' character
        findEndColumnForClosingTag: function(line, cursorColumn) {
            // Check if there's a '>' right after the cursor (Monaco's auto-insert)
            if (line.charAt(cursorColumn - 1) === '>') {
                return cursorColumn + 1;  // Include the '>'
            }
            return cursorColumn;
        },
        
        // Helper: Adjust range to include auto-inserted '>' after the word
        adjustRangeToIncludeAutoClosing: function(line, range) {
            const charAfterWord = line.charAt(range.endColumn - 1);
            if (charAfterWord === '>') {
                return {
                    startLineNumber: range.startLineNumber,
                    endLineNumber: range.endLineNumber,
                    startColumn: range.startColumn,
                    endColumn: range.endColumn + 1
                };
            }
            return range;
        },
        
        getOpenTags: function(model, position) {
            const tagInfo = this.getOpenTagsWithPositions(model, position);
            return tagInfo.map(info => info.name);
        },
        
        getOpenTagsWithPositions: function(model, position) {
            const textBeforeCursor = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column
            });
            
            // Remove XML comments to avoid false matches
            const cleanedText = textBeforeCursor.replace(/<!--[\s\S]*?-->/g, '');
            
            // Parse all tags and maintain a stack with position info
            const tagRegex = /<\/?([a-zA-Z0-9_.]+)(?:[\s\S]*?)(\/?)>/g;
            const tagStack = [];
            let match;
            
            while ((match = tagRegex.exec(cleanedText)) !== null) {
                const fullTag = match[0];
                const capturedName = match[1];
                const isSelfClosing = match[2] === '/';
                const isClosing = fullTag.startsWith('</');
                
                if (isClosing) {
                    // Remove matching open tag from stack
                    for (let i = tagStack.length - 1; i >= 0; i--) {
                        if (tagStack[i].name === capturedName || tagStack[i].name === capturedName.split('.')[0]) {
                            tagStack.splice(i, 1);
                            break;
                        }
                    }
                } else if (!isSelfClosing) {
                    // Find the indentation of this opening tag
                    // Look backwards from match.index to find the start of the line
                    const textUpToTag = cleanedText.substring(0, match.index);
                    const lastNewline = textUpToTag.lastIndexOf('\n');
                    const lineStart = lastNewline >= 0 ? lastNewline + 1 : 0;
                    const lineBeforeTag = cleanedText.substring(lineStart, match.index);
                    const indent = lineBeforeTag.match(/^(\s*)/)[1];
                    
                    tagStack.push({
                        name: capturedName,
                        indent: indent
                    });
                }
            }
            
            return tagStack;
        },
        
        detectContext: function(model, position, textUntilPosition) {
            const isAfterEquals = /[a-zA-Z0-9_]+\s*=\s*"[^"]*$/.test(textUntilPosition);
            const isAfterDot = /[a-zA-Z0-9_]+\.[a-zA-Z0-9_]*$/.test(textUntilPosition) && !isAfterEquals;
            const isAfterOpenTag = /<[a-zA-Z0-9_]*$/.test(textUntilPosition);
            const isClosingTag = /<\/[a-zA-Z0-9_.]*$/.test(textUntilPosition);
            
            // Check if inside unclosed tag by looking backwards for '<' or '>'
            const insideTag = this.isInsideTag(model, position);
            const isInAttribute = !isAfterOpenTag && !isAfterEquals && !isAfterDot && !isClosingTag && insideTag;
            
            return { isAfterEquals, isAfterDot, isAfterOpenTag, isClosingTag, isInAttribute };
        },
        
        isInsideTag: function(model, position) {
            // Look backwards to find the most recent '<' or '>'
            const startLine = Math.max(1, position.lineNumber - MAX_LOOKBACK_LINES);
            
            for (let lineNum = position.lineNumber; lineNum >= startLine; lineNum--) {
                const line = model.getLineContent(lineNum);
                const text = lineNum === position.lineNumber ? line.substring(0, position.column - 1) : line;
                
                // Check for the most recent '<' or '>'
                const lastClose = text.lastIndexOf('>');
                const lastOpen = text.lastIndexOf('<');
                
                if (lastClose > lastOpen) {
                    return false; // Found '>' first, we're outside a tag
                } else if (lastOpen >= 0) {
                    return true; // Found '<' first, we're inside a tag
                }
            }
            
            return false;
        },
        
        getEnumCompletions: function(textUntilPosition, range) {
            const propMatch = textUntilPosition.match(/([a-zA-Z0-9_]+)\s*=\s*"[^"]*$/);
            if (!propMatch) {
                return { suggestions: [], incomplete: false };
            }
            
            const propName = propMatch[1];
            const elementMatch = textUntilPosition.match(/<([a-zA-Z0-9_]+)[^<>]*$/);
            if (!elementMatch) {
                return { suggestions: [], incomplete: false };
            }
            
            const elementName = elementMatch[1];
            const typeInfo = this.completionData.elements[elementName];
            if (!typeInfo) {
                return { suggestions: [], incomplete: false };
            }
            
            const suggestions = [];
            for (const prop of typeInfo.properties || []) {
                if (prop.name === propName && prop.enumValues && prop.enumValues.length > 0) {
                    for (const enumValue of prop.enumValues) {
                        suggestions.push({
                            label: enumValue,
                            kind: monaco.languages.CompletionItemKind.EnumMember,
                            insertText: enumValue,
                            range: range
                        });
                    }
                    break;
                }
            }
            
            return { suggestions, incomplete: false };
        },
        
        getDotCompletions: function(textUntilPosition, range, model, position) {
            const dotMatch = textUntilPosition.match(/([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]*)$/);
            if (!dotMatch) {
                return { suggestions: [], incomplete: false };
            }
            
            const ownerType = dotMatch[1];
            const typeInfo = this.completionData.elements[ownerType];
            
            if (!typeInfo) {
                return { suggestions: [], incomplete: false };
            }
            
            // Check if this is a property element (after <ElementName.) vs attached property (inside attributes)
            const propertyElementPattern = new RegExp('<' + ownerType + '\\.[a-zA-Z0-9_]*$');
            const isPropertyElement = propertyElementPattern.test(textUntilPosition);
            const suggestions = [];
            
            if (isPropertyElement) {
                // Property element completion: <Grid.ColumnDefinitions>
                // Check if there's an auto-inserted '>' after the cursor that needs to be replaced
                const line = model.getLineContent(position.lineNumber);
                const adjustedRange = this.adjustRangeToIncludeAutoClosing(line, range);
                
                const seen = new Set();
                for (const prop of typeInfo.properties || []) {
                    if (!prop.isEvent && !seen.has(prop.name)) {
                        suggestions.push({
                            label: prop.name,
                            kind: monaco.languages.CompletionItemKind.Property,
                            insertText: prop.name + '>',
                            detail: 'Property element',
                            range: adjustedRange
                        });
                        seen.add(prop.name);
                    }
                }
            } else {
                // Attached property completion: Grid.Row=""
                for (const attachedProp of typeInfo.attachedProperties || []) {
                    suggestions.push({
                        label: attachedProp.name,
                        kind: monaco.languages.CompletionItemKind.Property,
                        insertText: attachedProp.name,
                        detail: 'Attached property',
                        range: range
                    });
                }
            }
            
            return { suggestions, incomplete: false };
        },
        
        getAttributeCompletions: function(model, position, range) {
            const textBeforeCursor = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column
            });
            
            // Find the most recent unclosed tag using negative lookahead to exclude self-closing and closed tags
            const tagMatches = [...textBeforeCursor.matchAll(/<([a-zA-Z0-9_]+)(?![^<]*\/?>)/g)];
            if (tagMatches.length === 0) {
                return { suggestions: [], incomplete: false };
            }
            
            const elementName = tagMatches[tagMatches.length - 1][1];
            const typeInfo = this.completionData.elements[elementName];
            
            if (!typeInfo) {
                return { suggestions: [], incomplete: false };
            }
            
            const suggestions = [];
            const seen = new Set();
            
            // Add properties and events from the current type
            for (const prop of typeInfo.properties || []) {
                if (!prop.isReadOnly && !seen.has(prop.name)) {
                    const suggestion = {
                        label: prop.name,
                        kind: prop.isEvent ? monaco.languages.CompletionItemKind.Event : monaco.languages.CompletionItemKind.Property,
                        insertText: prop.name + '="$0"',
                        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        range: range
                    };
                    if (prop.isEvent) {
                        suggestion.detail = 'Event';
                    }
                    suggestions.push(suggestion);
                    seen.add(prop.name);
                }
            }
            
            // Add all attached properties from all types
            for (const type of Object.values(this.completionData.elements)) {
                for (const attachedProp of type.attachedProperties || []) {
                    const fullName = type.name + '.' + attachedProp.name;
                    if (!seen.has(fullName)) {
                        suggestions.push({
                            label: fullName,
                            kind: monaco.languages.CompletionItemKind.Property,
                            insertText: fullName + '="$0"',
                            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                            detail: 'Attached property',
                            range: range
                        });
                        seen.add(fullName);
                    }
                }
            }
            
            return { suggestions, incomplete: false };
        },
        
        getElementCompletions: function(model, position, textUntilPosition, range) {
            // Check if completing a property element
            if (textUntilPosition.match(/<([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]*)$/)) {
                return this.getDotCompletions(textUntilPosition, range, model, position);
            }
            
            // Regular element completion with contextual filtering
            const parentInfo = this.findParentElement(model, position);
            
            // Check if parent accepts children
            if (parentInfo.parentElement) {
                const parent = this.completionData.elements[parentInfo.parentElement];
                if (parent && !parent.contentType && !parent.contentProperty) {
                    return { suggestions: [], incomplete: false };
                }
            }
            
            // Filter by type compatibility
            const suggestions = [];
            for (const typeInfo of Object.values(this.completionData.elements)) {
                if (!typeInfo.isAbstract && this.isTypeCompatible(typeInfo, parentInfo.parentContentType)) {
                    suggestions.push({
                        label: typeInfo.name,
                        kind: monaco.languages.CompletionItemKind.Class,
                        insertText: typeInfo.name,
                        detail: typeInfo.namespace,
                        range: range
                    });
                }
            }
            
            return { suggestions, incomplete: false };
        },
        
        findParentElement: function(model, position) {
            const textBeforeCursor = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column - 1
            });
            
            // Remove XML comments to avoid false matches
            const cleanedText = textBeforeCursor.replace(/<!--[\s\S]*?-->/g, '');
            
            // Parse all tags and maintain a stack to find the current parent
            const tagRegex = /<\/?([a-zA-Z0-9_.]+)(?:[\s\S]*?)(\/?)>/g;
            const tagStack = [];
            let match;
            
            while ((match = tagRegex.exec(cleanedText)) !== null) {
                const fullTag = match[0];
                const capturedName = match[1];
                const isSelfClosing = match[2] === '/';
                const isClosing = fullTag.startsWith('</');
                
                if (isClosing) {
                    for (let i = tagStack.length - 1; i >= 0; i--) {
                        if (tagStack[i] === capturedName || tagStack[i] === capturedName.split('.')[0]) {
                            tagStack.splice(i, 1);
                            break;
                        }
                    }
                } else if (!isSelfClosing) {
                    tagStack.push(capturedName);
                }
            }
            
            let parentElement = tagStack.length > 0 ? tagStack[tagStack.length - 1] : null;
            let parentContentType = null;
            
            if (parentElement) {
                // Check if parent is a property element
                const propertyElementMatch = parentElement.match(/^([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)$/);
                
                if (propertyElementMatch) {
                    const ownerTypeName = propertyElementMatch[1];
                    const propertyName = propertyElementMatch[2];
                    const ownerTypeInfo = this.completionData.elements[ownerTypeName];
                    
                    if (ownerTypeInfo) {
                        // Find the property to determine what type of children it accepts
                        const prop = ownerTypeInfo.properties?.find(p => p.name === propertyName);
                        if (prop) {
                            parentContentType = prop.typeName;
                        }
                    }
                } else {
                    const parentInfo = this.completionData.elements[parentElement];
                    if (parentInfo && parentInfo.contentType) {
                        parentContentType = parentInfo.contentType;
                    }
                }
            }
            
            return { parentElement, parentContentType };
        },
        
        isTypeCompatible: function(typeInfo, requiredType) {
            if (!requiredType) return true;
            if (requiredType === 'System.Object') return true;
            if (typeInfo.fullName === requiredType) return true;
            if (typeInfo.baseTypes && typeInfo.baseTypes.includes(requiredType)) return true;
            return false;
        }
    };
})();

