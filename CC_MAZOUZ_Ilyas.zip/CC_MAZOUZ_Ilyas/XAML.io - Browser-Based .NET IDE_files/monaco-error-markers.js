/**
 * Monaco Error Markers Module
 * 
 * Provides error underlining and line highlighting functionality for Monaco Editor.
 * Shows red wavy underlines on error positions and highlights error lines with a reddish background.
 * 
 * To disable this feature, simply don't load this script or set window.MonacoErrorMarkers.enabled = false
 */
(function() {
    'use strict';

    // Module state
    let errorLineDecorations = [];
    let enabled = true;

    /**
     * Check if a character is a word character (letter, digit, or underscore)
     */
    function isWordChar(c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c === '_';
    }

    /**
     * Find the word range at/after the given position
     * Only expands forward from the error position to find the word
     */
    function findWordRangeAtPosition(model, lineNumber, column) {
        const lineContent = model.getLineContent(lineNumber);
        if (!lineContent) return null;

        let startCol = column;
        let endCol = column;

        // First try Monaco's built-in word detection
        const wordAtPos = model.getWordAtPosition({ lineNumber: lineNumber, column: column });
        if (wordAtPos) {
            return {
                startColumn: wordAtPos.startColumn,
                endColumn: wordAtPos.endColumn
            };
        }

        // Fallback: manually find word boundaries
        // Expand forward to find end of word
        while (endCol <= lineContent.length && isWordChar(lineContent.charAt(endCol - 1))) {
            endCol++;
        }
        // Expand backward to find start of word
        while (startCol > 1 && isWordChar(lineContent.charAt(startCol - 2))) {
            startCol--;
        }

        // If we couldn't find a word, underline a few characters
        if (startCol === endCol) {
            endCol = Math.min(startCol + 10, lineContent.length + 1);
        }

        return { startColumn: startCol, endColumn: endCol };
    }

    /**
     * Set error markers on the editor
     * @param {Array} errors - Array of error objects with line, column, and message properties
     */
    function setErrorMarkers(errors) {
        if (!enabled) return;

        const element = document.getElementById('monacoContainer');
        if (!element || !element.editor) return;

        try {
            const model = element.editor.getModel();
            if (!model) return;

            // Clear previous line decorations
            errorLineDecorations = element.editor.deltaDecorations(errorLineDecorations, []);

            if (!errors || errors.length === 0) {
                monaco.editor.setModelMarkers(model, 'compilation', []);
                return;
            }

            const markers = [];
            const lineDecorations = [];
            const processedLines = new Set();

            for (const err of errors) {
                if (!err.line || err.line < 1) continue;

                const lineNumber = err.line;
                const column = err.column || 1;

                // Find word range at error position
                const range = findWordRangeAtPosition(model, lineNumber, column);
                if (!range) continue;

                // Add model marker (red wavy underline)
                markers.push({
                    severity: monaco.MarkerSeverity.Error,
                    message: err.message || 'Error',
                    startLineNumber: lineNumber,
                    startColumn: range.startColumn,
                    endLineNumber: lineNumber,
                    endColumn: range.endColumn
                });

                // Add line decoration (reddish background) - only once per line
                if (!processedLines.has(lineNumber)) {
                    processedLines.add(lineNumber);
                    lineDecorations.push({
                        range: new monaco.Range(lineNumber, 1, lineNumber, 1),
                        options: {
                            isWholeLine: true,
                            className: 'error-line-highlight'
                        }
                    });
                }
            }

            // Apply model markers (wavy underlines)
            monaco.editor.setModelMarkers(model, 'compilation', markers);

            // Apply line decorations (background color)
            errorLineDecorations = element.editor.deltaDecorations([], lineDecorations);

        } catch (ex) {
            console.error('[MonacoErrorMarkers] Error setting markers:', ex);
        }
    }

    /**
     * Clear all error markers and line highlights
     */
    function clearErrorMarkers() {
        const element = document.getElementById('monacoContainer');
        if (!element || !element.editor) return;

        try {
            const model = element.editor.getModel();
            if (model) {
                monaco.editor.setModelMarkers(model, 'compilation', []);
            }
            errorLineDecorations = element.editor.deltaDecorations(errorLineDecorations, []);
        } catch (ex) {
            console.error('[MonacoErrorMarkers] Error clearing markers:', ex);
        }
    }

    // Expose module API
    window.MonacoErrorMarkers = {
        setErrorMarkers: setErrorMarkers,
        clearErrorMarkers: clearErrorMarkers,
        get enabled() { return enabled; },
        set enabled(value) { enabled = value; }
    };

    // Also expose as window functions for backward compatibility
    window.setErrorMarkers = setErrorMarkers;
    window.clearErrorMarkers = clearErrorMarkers;

})();

