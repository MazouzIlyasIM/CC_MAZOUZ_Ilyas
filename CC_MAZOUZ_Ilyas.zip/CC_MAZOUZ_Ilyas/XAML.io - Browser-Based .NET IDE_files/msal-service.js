﻿(function () {
    'use strict';

    window.MsalService = window.MsalService || {};

    const config = {
        clientId: "245a90e2-f202-445a-a038-81367b8bb265",
        authority: "https://login.microsoftonline.com/common",
        redirectUri: "/xamldes/index.html",
        cacheLocation: "localStorage",
        appName: "Xaml Designer App",
        appVersion: "3.0",
        scopes: ["email", "profile", "openid", "api://245a90e2-f202-445a-a038-81367b8bb265/xamldes.aiaccess"]
    };

    let msalInstance = null;
    let isInitialized = false;
    let currentAccount = null;
    let currentToken = null;
    let initPromise = null;
    let initCallbacks = [];

    function loadMsalLibrary() {
        return new Promise((resolve, reject) => {
            // Check if already loaded
            if (window.msal && window.msal.PublicClientApplication) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@azure/msal-browser@3.17.0/lib/msal-browser.min.js';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    async function initialize() {
        if (initPromise) {
            return initPromise;
        }

        initPromise = (async () => {
            try {
                await loadMsalLibrary();

                msalInstance = new msal.PublicClientApplication({
                    auth: {
                        clientId: config.clientId,
                        authority: config.authority,
                        redirectUri: config.redirectUri,
                    },
                    cache: {
                        cacheLocation: config.cacheLocation,
                        storeAuthStateInCookie: false,
                    },
                    system: {
                        loggerOptions: {
                            logLevel: msal.LogLevel.Error,
                            loggerCallback: (level, message, containsPii) => {
                                if (containsPii) {
                                    return;
                                }
                                switch (level) {
                                    case msal.LogLevel.Error:
                                        console.error(message);
                                        return;
                                    case msal.LogLevel.Info:
                                        console.info(message);
                                        return;
                                    case msal.LogLevel.Verbose:
                                        console.debug(message);
                                        return;
                                    case msal.LogLevel.Warning:
                                        console.warn(message);
                                        return;
                                    default:
                                        console.log(message);
                                        return;
                                }
                            },
                        },
                    },
                    telemetry: {
                        application: {
                            appName: config.appName,
                            appVersion: config.appVersion
                        },
                    }
                });

                await msalInstance.initialize();

                const accounts = msalInstance.getAllAccounts();
                if (accounts.length > 0) {
                    msalInstance.setActiveAccount(accounts[0]);
                    currentAccount = accounts[0];
                }

                isInitialized = true;

                // Try to refresh token silently immediately
                let token = await updateTokenSilently();

                initCallbacks.forEach(cb => cb(token.accessToken, token.name, token.username));
                initCallbacks = null;

                return true;
            } catch (error) {
                console.error('Failed to initialize MSAL:', error);
                throw error;
            }
        })();

        return initPromise;
    }

    async function updateTokenSilently() {
        if (!isInitialized) {
            await initialize();
        }

        try {
            // Try acquireTokenSilent first
            const silentRequest = {
                scopes: config.scopes,
                account: msalInstance.getActiveAccount()
            };

            try {
                const response = await msalInstance.acquireTokenSilent(silentRequest);
                currentToken = response.accessToken;
                currentAccount = response.account;
                return {
                    accessToken: response.accessToken,
                    name: response.account.name,
                    username: response.account.username
                };
            } catch (silentError) {
                console.log("Cannot get token silently:", silentError.message);

                // Try SSO silent
                try {
                    const ssoResponse = await msalInstance.ssoSilent({
                        scopes: config.scopes
                    });
                    currentToken = ssoResponse.accessToken;
                    currentAccount = ssoResponse.account;
                    return {
                        accessToken: ssoResponse.accessToken,
                        name: ssoResponse.account.name,
                        username: ssoResponse.account.username
                    };
                } catch (ssoError) {
                    console.log("Cannot do sso silently:", ssoError.message);
                    currentToken = null;
                    return {
                        accessToken: null,
                        name: null,
                        username: null
                    };
                }
            }
        } catch (error) {
            console.error('Error updating token:', error);
            currentToken = null;
            return {
                accessToken: null,
                name: null,
                username: null
            };
        }
    }

    async function showLoginPopup() {
        if (!isInitialized) {
            await initialize();
        }

        try {
            const response = await msalInstance.loginPopup({
                prompt: "select_account",
                scopes: config.scopes,
                redirectUri: config.redirectUri
            });

            msalInstance.setActiveAccount(response.account);
            currentToken = response.accessToken;
            currentAccount = response.account;

            return {
                accessToken: response.accessToken,
                name: response.account.name,
                username: response.account.username
            };
        } catch (error) {
            console.log(error);
            return {
                accessToken: null,
                name: null,
                username: null
            };
        }
    }

    window.MsalService = {
        isInitialized: () => isInitialized,

        onInitialized: (callback) => {
            if (initCallbacks === null) {
                callback(currentToken, currentAccount?.name, currentAccount?.username);
            } else {
                initCallbacks.push(callback);
            }
        },

        initialize: initialize,

        showLoginPopup: showLoginPopup,

        updateTokenSilently: updateTokenSilently,

        getAccessToken: () => currentToken,

        getAccount: () => currentAccount ? {
            name: currentAccount.name,
            username: currentAccount.username
        } : null,

        version: 1
    };

    initialize();
})();
